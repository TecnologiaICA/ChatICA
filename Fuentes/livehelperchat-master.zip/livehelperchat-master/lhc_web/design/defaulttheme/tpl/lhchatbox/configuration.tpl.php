<h1><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('chatbox/configuration','Chatbox');?></h1>

<h4><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('chatbox/configuration','General');?></h4>
<ul>
    <li><a href="<?php echo erLhcoreClassDesign::baseurl('chatbox/generalsettings')?>"><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('chatbox/configuration','General settings');?></a></li>
    <li><a href="<?php echo erLhcoreClassDesign::baseurl('chatbox/list')?>"><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('chatbox/configuration','Chatbox list');?></a></li>
</ul>