export const addArticle = article => ({
    type: "ADD_ARTICLE",
    payload: article
});