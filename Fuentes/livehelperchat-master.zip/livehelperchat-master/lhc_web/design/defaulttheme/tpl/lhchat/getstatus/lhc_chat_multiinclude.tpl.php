<?php 
/**
 * You can override some main lhc javascript object attributes, or create a new one
 * E.g
 * lh_inst.someFunction = function(){
 * 
 * }
 * */
?>