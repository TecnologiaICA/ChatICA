<?php include(erLhcoreClassDesign::designtpl('lhchat/syncadmin.tpl.php'));?>
<?php if ($initial == true) : ?>
    <div class="alert alert-info" role="alert" style="margin:10px 10px 30px 10px;padding:5px">
        <p align="center"><b><i class="material-icons">&#xE316;</i><i class="material-icons">&#xE316;</i><i class="material-icons">&#xE316;</i> <i class="material-icons fs24">&#xE889;</i> <i class="material-icons">&#xE316;</i><i class="material-icons">&#xE316;</i><i class="material-icons">&#xE316;</i></b></p>
    </div>
<?php endif; ?>