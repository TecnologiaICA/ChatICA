<h1><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('chatarchive/process','Process archive');?></h1>

<?php include(erLhcoreClassDesign::designtpl('lhchatarchive/process_content.tpl.php'));?>