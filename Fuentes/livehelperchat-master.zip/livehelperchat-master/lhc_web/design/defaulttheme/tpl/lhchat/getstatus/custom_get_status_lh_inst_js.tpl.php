<?php 
/**
 * Custom get status JS i lh_inst object
 * */
?>