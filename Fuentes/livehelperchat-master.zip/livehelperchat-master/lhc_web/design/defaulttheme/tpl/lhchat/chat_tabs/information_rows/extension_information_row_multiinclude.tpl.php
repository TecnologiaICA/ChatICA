<?php
// Override me
// $buttonData['item'] - holds identifier for a row
?>