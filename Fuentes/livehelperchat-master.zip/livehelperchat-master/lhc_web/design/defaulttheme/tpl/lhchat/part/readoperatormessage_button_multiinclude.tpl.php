<?php 
/**
 * here you can include custom buttons for read operator message window
 * */
?>