<?php 
/**
 * Here you can have custom button in chat window top right corner
 * */
?>