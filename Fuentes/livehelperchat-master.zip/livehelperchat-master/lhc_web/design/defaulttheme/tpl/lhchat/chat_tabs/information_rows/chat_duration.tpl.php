<tr>
    <td><?php echo erTranslationClassLhTranslation::getInstance()->getTranslation('chat/adminchat','Chat duration')?></td>
    <td id="chat-duration-<?php echo $chat->id?>"><?php echo $chat->chat_duration_front?></td>
</tr>