<?php 
/*
 * Override me and have any tab content you want there, $chat variable will contain chat itself
 * 
 * <div role="tabpanel" class="tab-pane" id="main-extension-chat-<?php echo $chat->id?>"></div>
 * * */
?>