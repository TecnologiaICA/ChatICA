$(function() {
    $('#side-menu').metisMenu();
});
