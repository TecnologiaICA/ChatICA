<?php include(erLhcoreClassDesign::designtpl('lhchat/part/after_text_area_multiinclude.tpl.php')); ?>

<div class="form-group">
<?php include(erLhcoreClassDesign::designtpl('lhchat/part/action_block.tpl.php')); ?>

<?php include(erLhcoreClassDesign::designtpl('lhchat/part/below_action_block.tpl.php')); ?>
</div>