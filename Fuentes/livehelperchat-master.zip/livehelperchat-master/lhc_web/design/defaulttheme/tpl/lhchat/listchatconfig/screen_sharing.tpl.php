<div role="tabpanel" class="tab-pane" id="screen-sharing">
    <?php $attribute = 'sharing_auto_allow';$boolValue = true;?>
    <?php include(erLhcoreClassDesign::designtpl('lhchat/part/chat_settings.tpl.php'));?>
 
    <?php $attribute = 'disable_js_execution';$boolValue = true;?>
    <?php include(erLhcoreClassDesign::designtpl('lhchat/part/chat_settings.tpl.php'));?>
 
    <?php $attribute = 'sharing_nodejs_enabled';$boolValue = true;?>
    <?php include(erLhcoreClassDesign::designtpl('lhchat/part/chat_settings.tpl.php'));?>
 
    <?php $attribute = 'sharing_nodejs_secure';$boolValue = true;?>
    <?php include(erLhcoreClassDesign::designtpl('lhchat/part/chat_settings.tpl.php'));?>
 
    <?php $attribute = 'disable_iframe_sharing';$boolValue = true;?>
    <?php include(erLhcoreClassDesign::designtpl('lhchat/part/chat_settings.tpl.php'));?>
 
    <?php $attribute = 'sharing_nodejs_socket_host';?>
    <?php include(erLhcoreClassDesign::designtpl('lhchat/part/chat_settings.tpl.php'));?>
 
    <?php $attribute = 'sharing_nodejs_sllocation';?>
    <?php include(erLhcoreClassDesign::designtpl('lhchat/part/chat_settings.tpl.php'));?>
 
    <?php $attribute = 'sharing_nodejs_path';?>
    <?php include(erLhcoreClassDesign::designtpl('lhchat/part/chat_settings.tpl.php'));?>
    
</div>