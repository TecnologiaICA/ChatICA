<?php 
/**
 * Included after validation errors just above normal chat form starts
 */
?>